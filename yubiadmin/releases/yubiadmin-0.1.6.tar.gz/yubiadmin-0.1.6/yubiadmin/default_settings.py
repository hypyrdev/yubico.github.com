#
# YubiAdmin settings
#

# Credentials needed to access the web interface
USERNAME = "yubiadmin"
PASSWORD = "yubiadmin"

# Interface to listen to
INTERFACE = "127.0.0.1"

# Listen port
PORT = 8080
