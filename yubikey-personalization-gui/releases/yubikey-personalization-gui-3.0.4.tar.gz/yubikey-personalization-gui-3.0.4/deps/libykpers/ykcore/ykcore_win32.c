/* -*- mode:C; c-file-style: "bsd" -*- */
/* Please implement this.  Have a look at ykcore_libusb.c or some other
   already implemented backend for inspiration. */
#include "ykcore_stub.c"
