# Copyright (c) 2010, 2011, 2012 Yubico AB
# See the file COPYING for licence statement.

"""
Tests that run against a physical YubiKey.
These tests require an attached YubiKey that has been correctly configured.
"""
